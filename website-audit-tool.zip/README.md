# Website Health Check

A self-hosted site audit tool. Paste in a customer's URL, get a scored report on
search visibility, visitor experience, site freshness and blog activity.

No third-party APIs, no API keys, no npm dependencies.

## Deploy

1. Drag this whole folder onto https://app.netlify.com/drop, or push it to a
   Git repo and connect it in Netlify.
2. That's it. `netlify.toml` tells Netlify where the front end and the function live.

Local preview: `npm i -g netlify-cli` then `netlify dev`.

## Branding

Two places to edit, both in `public/index.html`:

- The masthead near the top of `<body>` (`<div class="brand">` and `<div class="by">`)
- The `<footer>` at the bottom

Colors live in the `:root` block at the top of the `<style>` tag. `--signal` is
the accent; change that one value to re-skin the whole tool.

The disclaimer text is in the `render()` function, in the `<div class="disclaimer">`
block. Keep it in place — it is what appears on the printed PDF.

## What it checks, with no API

**Search visibility (35 pts)** — title, meta description, H1/H2/H3 structure,
word count, internal vs external links, alt text coverage, canonical tag,
Open Graph and Twitter tags, JSON-LD schema, robots meta, robots.txt, XML sitemap.

**Visitor experience (30 pts)** — HTTPS, redirect chain, server response time,
HTML weight, script and stylesheet counts, lazy loading, image dimensions,
WebP/AVIF usage, compression, caching headers, security headers, tap-to-call
link, contact form presence.

**Site freshness (20 pts)** — sitemap `<lastmod>` distribution (newest, oldest,
how many pages are stale over a year, how many changed in 90 days),
`Last-Modified` header, footer copyright year.

**Blog activity (15 pts)** — RSS/Atom feed discovery via `<link rel=alternate>`
plus nine common feed paths, falling back to crawling `/blog`, `/news`,
`/articles` and reading `<time datetime>`, `datePublished` and visible dates.
Reports post count, days since last post, posts in the last 90/365 days,
average gap between posts and a cadence label.

Also detects the platform (WordPress, Shopify, Wix, Squarespace, GoDaddy
Website Builder, Webflow, Duda and others).

## Phase 1 APIs (installed, both free)

**RDAP** (`analyzeDomain` in `audit.js`) returns registrar, registration date,
domain age, expiry, privacy protection, DNSSEC and nameservers. No key, no
signup, no quota. Already live.

**Google PageSpeed Insights** (`netlify/functions/psi.js`) returns Lighthouse
scores for performance, accessibility, best practices and SEO, plus lab timings,
top speed opportunities, and real-user Core Web Vitals from the Chrome UX Report
where Google has enough traffic for that page.

Set up:
1. console.cloud.google.com, new project, no billing needed
2. APIs & Services, Library, enable "PageSpeed Insights API"
3. APIs & Services, Credentials, Create API key
4. Restrict the key to the PageSpeed Insights API only
5. Netlify, Site configuration, Environment variables, add `PSI_API_KEY`
6. Redeploy

Quota is 25,000 requests/day and about 240/minute. There is no paid tier and no
way to exceed the free allowance at normal usage. Without `PSI_API_KEY` set, the
tool still works and that one section shows a configuration notice.

Why this is a separate function: Lighthouse takes 10 to 30 seconds, and Netlify
synchronous functions time out at 10 by default. The front end renders the fast
report first, then calls `psi.js` and fills the section in when it lands.

## Adding paid APIs later

The function returns one JSON object. To add a data source, write another
async analyzer, add it to the `Promise.all` in the handler, and add its points
to `scoreAudit`. Slots worth filling, roughly in order of value:

| Data | Source | Cost |
|---|---|---|
| Performance, accessibility, Core Web Vitals | Google PageSpeed Insights API | Free, needs a key |
| Domain age, registrar, expiry | RDAP (`https://rdap.org/domain/<name>`) | Free, no key |
| Backlinks, domain authority | DataForSEO, Ahrefs, Semrush, Moz | Paid |
| Keyword rankings | DataForSEO, Semrush | Paid |
| Google Business Profile | Google Places API | Pay as you go |

Store keys as Netlify environment variables and read them with
`process.env.YOUR_KEY` inside the function. Never put a key in `public/`.

## Safety notes

- Every URL and every redirect hop is DNS-resolved and checked against private
  IP ranges, so the tool cannot be pointed at localhost, `10.x`, `192.168.x`,
  `169.254.x` or link-local addresses.
- Rate limited to 6 scans per minute per IP. This is per warm function instance
  and is a speed bump, not a wall. If the tool gets abused, move the counter to
  Netlify Blobs or Upstash Redis so it is shared across instances.
- Requests time out at 12 seconds and responses are capped at 2.5 MB.
- The tool identifies itself with a `QuixSiteAudit/1.0` user agent.

## Known limits

- JavaScript-rendered sites (some React/Vue builds) will show low word counts
  and missing headings, because the function reads the served HTML and does not
  run scripts. Worth mentioning to a customer before you show them the report.
- Sites behind Cloudflare bot protection may return 403.
- Only the homepage is analyzed in depth. The sitemap gives site-wide freshness,
  but SEO tags are read from the one page.
